﻿using ProjekcikASP.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class Articles
    {
        [Key]
        public int Id { get; set; }
        public string ArticleTitle { get; set; }
        public string ArticleText { get; set; }
        public int CategoryId { get; set; }
        public int RatingId { get; set; }
        public int UserId { get; set; }
        public int CarId { get; set; }
        public int CommentsId { get; set; }
        public virtual Cars Car { get; set; }
        public virtual ICollection<Rating> Rating { get; set; }
        public virtual ICollection<Comments> Comments { get; set; }
    [Required]
        public virtual User User { get; set; }
        

    }
}